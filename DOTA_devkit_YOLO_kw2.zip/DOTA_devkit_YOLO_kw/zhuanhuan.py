
import sys
sys.path.append("..")  # 将上层目录添加到系统路径中

# from utils.utils_rbox import rbox2poly

import os
from tqdm import tqdm
import os, cv2
import numpy as np
import math
pi = np.pi 


def rbox2poly_0(obboxes):
    """Convert oriented bounding boxes to polygons.
    Args:
        obbs (ndarray): [x_ctr,y_ctr,w,h,angle]
    Returns:
        polys (ndarray): [x0,y0,x1,y1,x2,y2,x3,y3]
    """
    try:
        center, w, h, theta = np.split(obboxes, (2, 3, 4), axis=-1)
    except:
        results = np.stack([0., 0., 0., 0., 0., 0., 0., 0.], axis=-1)
        return results.reshape(1, -1)
    Cos, Sin = np.cos(theta), np.sin(theta)
    vector1 = np.concatenate([w / 2 * Cos, w / 2 * Sin], axis=-1)
    vector2 = np.concatenate([-h / 2 * Sin, h / 2 * Cos], axis=-1)
    point1 = center - vector1 - vector2
    point2 = center + vector1 - vector2
    point3 = center + vector1 + vector2
    point4 = center - vector1 + vector2
    polys = [point1[0],point1[1], point2[0], point2[1], point3[0], point3[1], point4[0], point4[1]]
    x1, y1, x2, y2, x3, y3, x4, y4 = polys
    xmin = min(x1, x2, x3, x4)
    ymin = min(y1, y2, y3, y4)
    xmax = max(x1, x2, x3, x4)
    ymax = max(y1, y2, y3, y4)
    # combine = [[[x1, y1], [x2, y2], [x3, y3], [x4, y4]],
    #            [[x2, y2], [x3, y3], [x4, y4], [x1, y1]],
    #            [[x3, y3], [x4, y4], [x1, y1], [x2, y2]],
    #            [[x4, y4], [x1, y1], [x2, y2], [x3, y3]]]
    dst_coordinate = [xmin, ymin, xmax, ymin, xmax, ymax, xmin, ymax]

    return dst_coordinate 

def cal_line_length(point1, point2):
    """Calculate the length of line.
    Args:
        point1 (List): [x,y]
        point2 (List): [x,y]
    Returns:
        length (float)
    """
    return math.sqrt(
        math.pow(point1[0] - point2[0], 2) +
        math.pow(point1[1] - point2[1], 2))

def get_best_begin_point_single(coordinate):
    """Get the best begin point of the single polygon.
    Args:
        coordinate (List): [x1, y1, x2, y2, x3, y3, x4, y4, score]
    Returns:
        reorder coordinate (List): [x1, y1, x2, y2, x3, y3, x4, y4, score]
    """
    x1, y1, x2, y2, x3, y3, x4, y4 = coordinate
    xmin = min(x1, x2, x3, x4)
    ymin = min(y1, y2, y3, y4)
    xmax = max(x1, x2, x3, x4)
    ymax = max(y1, y2, y3, y4)
    combine = [[[x1, y1], [x2, y2], [x3, y3], [x4, y4]],
               [[x2, y2], [x3, y3], [x4, y4], [x1, y1]],
               [[x3, y3], [x4, y4], [x1, y1], [x2, y2]],
               [[x4, y4], [x1, y1], [x2, y2], [x3, y3]]]
    dst_coordinate = [[xmin, ymin], [xmax, ymin], [xmax, ymax], [xmin, ymax]]
    force = 100000000.0
    force_flag = 0
    for i in range(4):
        temp_force = cal_line_length(combine[i][0], dst_coordinate[0]) \
                     + cal_line_length(combine[i][1], dst_coordinate[1]) \
                     + cal_line_length(combine[i][2], dst_coordinate[2]) \
                     + cal_line_length(combine[i][3], dst_coordinate[3])
        if temp_force < force:
            force = temp_force
            force_flag = i
    if force_flag != 0:
        pass
    return np.hstack(
        (np.array(combine[force_flag]).reshape(8)))

def get_best_begin_point(coordinates):
    """Get the best begin points of polygons.
    Args:
        coordinate (ndarray): shape(n, 8).
    Returns:
        reorder coordinate (ndarray): shape(n, 8).
    """
    coordinates = list(map(get_best_begin_point_single, [coordinates.tolist()]))
    coordinates = np.array(coordinates)
    return coordinates

def rbox2poly(obboxes):
    """Convert oriented bounding boxes to polygons.
    Args:
        obbs (ndarray): [x_ctr,y_ctr,w,h,angle]
    Returns:
        polys (ndarray): [x0,y0,x1,y1,x2,y2,x3,y3]
    """
    try:
        center, w, h, theta = np.split(obboxes, (2, 3, 4), axis=-1)
    except:
        results = np.stack([0., 0., 0., 0., 0., 0., 0., 0.], axis=-1)
        return results.reshape(1, -1)
    theta = theta*math.pi/180
    Cos, Sin = np.cos(theta), np.sin(theta)
    vector1 = np.concatenate([w / 2 * Cos, w / 2 * Sin], axis=-1)
    vector2 = np.concatenate([-h / 2 * Sin, h / 2 * Cos], axis=-1)
    point1 = center - vector1 - vector2
    point2 = center + vector1 - vector2
    point3 = center + vector1 + vector2
    point4 = center - vector1 + vector2
    polys = np.concatenate([point1, point2, point3, point4], axis=-1)
    polys = get_best_begin_point(polys)
    # return polys
    return list(np.squeeze(polys))

def forward_convert(coordinate, with_label=False, recitifed=False):
        """
        :param coordinate: format [x_c, y_c, w, h, theta]
        :return: format [x1, y1, x2, y2, x3, y3, x4, y4]
        """
        # boxes = []
        if with_label:
            rect = coordinate
            x, y, w, h, angle, label = rect
            if recitifed:
                if angle < -90:
                    h, w = w, h
                    angle = angle + 90
            box = cv2.boxPoints(((x, y), (w, h), angle))
            box = np.reshape(box, [-1, ])
            boxes = [box[0], box[1], box[2], box[3], box[4], box[5], box[6], box[7], label]
        else:
            rect = coordinate
            x, y, w, h, angle = rect
            if recitifed:
                if angle < -90:
                    h, w = w, h
                    angle = angle + 90
            angle = angle*(180/pi)
            box = cv2.boxPoints(((x, y), (w, h), angle))
            box = np.reshape(box, [-1, ])
            boxes = [box[0], box[1], box[2], box[3], box[4], box[5], box[6], box[7]]

        return boxes

def write_to_file(out_results_path, lst):
    with open(out_results_path, 'a') as file:
        for item in lst:
            file.write("{} ".format(item))
        file.write('\n')

def main(results_path, out_path, img_x, img_y, cls_dic):


    for root_txt, dirs_txt, files_txt in os.walk(results_path):
        
        # for txt_file in tqdm(sorted(files_txt)):
        for txt_file in tqdm(files_txt):
            txt_file_path = os.path.join(results_path, txt_file)
            if txt_file.endswith('.txt'):
                with open(txt_file_path, 'r') as f:
                    lines = f.readlines()
                for line in lines:
                    line = line.strip('\n')
                    [P_cls, x0, y0, x1, y1, x2, y2, x3, y3, conf_score] = line.split(' ')

                    P_cls_name = cls_dic[P_cls]

                    out_cls_name = P_cls_name + '.txt'
                    out_results_path = os.path.join(out_path, out_cls_name)
                    # if not os.path.isdir(out_results_path):
                    #     os.mkdir(out_results_path)
                    if not os.path.exists(out_results_path):
                        with open(out_results_path, 'w') as f:
                            pass
                    
                    txt_file_name = txt_file.split('.')[0]

                    x0 = float(x0) *img_x
                    x1 = float(x1) *img_x
                    x2 = float(x2) *img_x
                    x3 = float(x3) *img_x
                    y0 = float(y0) *img_y
                    y1 = float(y1) *img_y
                    y2 = float(y2) *img_y
                    y3 = float(y3) *img_y

                    new_lines = [txt_file_name, conf_score, str(x0), str(y0), str(x1), str(y1), str(x2), str(y2), str(x3), str(y3)]

                    write_to_file(out_results_path, new_lines)

                






if __name__ == '__main__':

    results_path = 'our_data/labels_results/'
    out_path     = 'our_data/class_results/'

    img_x = 840
    img_y = 712
    cls_dic = {'0':'car', '1':'freight_car', '2':'truck', '3':'bus', '4':'van'}

    main(results_path, out_path, img_x, img_y, cls_dic)

