//
// Created by dingjian on 18-2-3.
//

#ifndef POLYIOU_POLYIOU_H
#define POLYIOU_POLYIOU_H

#include <vector>
double iou_poly(std::vector<double> p, std::vector<double> q);
#endif //POLYIOU_POLYIOU_H
