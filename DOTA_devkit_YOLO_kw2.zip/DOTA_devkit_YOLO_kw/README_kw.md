1. 对yolo输出格式，先用zhuanhuan.py将输出格式转换为DOTO格式。
2. 使用Drone_evaluation_task1.py进行测试。

注：这里已提供ADMPF结果，可跳过第1步。