import os

def write_image_paths_to_txt(folder_path1, folder_path2, output_file):
    # 检查输出文件及其所在路径是否存在，不存在则创建
    output_dir = os.path.dirname(output_file)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    if not os.path.exists(output_file):
        open(output_file, 'w').close()

    with open(output_file, 'w') as f:
        for folder_path in [folder_path1, folder_path2]:
            for root, dirs, files in os.walk(folder_path):
                for file in files:
                    if file.endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp')):
                        image_path = os.path.abspath(os.path.join(root, file))
                        f.write(image_path + '\n')

folder_path1 = "/data/pdl/lkw/Datasets_w1/DroneVehicle/images/val_md_IR/"
folder_path2 = "/data/pdl/lkw/Datasets_w1/DroneVehicle/images/val_md_VIS/"
output_file = "image_paths.txt"

write_image_paths_to_txt(folder_path1, folder_path2, output_file)